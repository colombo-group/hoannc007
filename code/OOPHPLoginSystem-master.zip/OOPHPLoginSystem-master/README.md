OOPHPLoginSystem
================

OOPHP Login and registration system, created from the PHPAcademy OOP Tutorial.

[YouTube Playlist of tutorial](http://www.youtube.com/playlist?list=PLfdtiltiRHWF5Rhuk7k4UAU1_yLAZzhWc)
